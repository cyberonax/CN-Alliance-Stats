Cyber Nations Statistics Files

Introduction:

The Cyber Nations downloadable statistics files are for advanced users who wish to obtain statistics of in-game data. These data output files are made available to you to allow for statistics gathering without breaking the Cyber Nations terms and conditions that prohibit automated screen scrapping and other automated scripts or bots that interact with the game. The statistics download files are updated every 12 hours and should be available to download by 6:00 AM and 6:00 PM server time.

How To Use:

There are many ways to use these output files. Common applications such as Microsoft Excel or Microsoft Access will allow you to import the files as external data by specifying the pipe character �|� as the separator between the data fields. There are also many other data tools available on the web to help you work with these data files.

License Agreement:

All data herein officially belongs to Cyber Nations. You may use these files for statistics gathering purposes for the online game Cyber Nations found at http://www.cybernations.net. Any other use of this data without Cyber Nations administrative consent is a violation of this agreement. Any use of these data files that may interfere, cause harm, or compete with Cyber Nations is prohibited. This license agreement does not pass to the user any title to or any proprietary rights of the data in the contained files, all of the same being expressly reserved to and vested in Cyber Nations and protected by United States copyright laws and international treaty provisions, as well as other intellectual property laws and treaties. Nor shall the user acquire any right or interest in the contained files as a result of any changes to, modifications of or additions to these files made by Cyber Nations. Any modifications, updates or enhancements to these files arising directly or indirectly out of any exchange of information with the user are the exclusive property of Cyber Nations. Download or use of these files constitutes acceptance of the terms of this agreement.